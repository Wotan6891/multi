# Marko Run notes for this project

When developing locally:

1. Rename route files to Marko Run convention:
   - `src/routes/index.marko` → `src/routes/+page.marko`
   - `src/routes/admin/layout.marko` → `src/routes/admin/+layout.marko`
   - `src/routes/admin/index.marko` → `src/routes/admin/+page.marko`
   - same for vendor/

2. Or configure in vite.config:
```ts
import { defineConfig } from "vite";
import marko from "@marko/run/vite";

export default defineConfig({
  plugins: [marko()],
});
```

3. Install & run:
```bash
bun install
bunx marko-run
```
