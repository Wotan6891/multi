import { sqliteTable, text, integer, real } from "drizzle-orm/sqlite-core";
import { relations } from "drizzle-orm";

// ─── Users ───────────────────────────────────────────────────────────────────
export const users = sqliteTable("users", {
  id: text("id").primaryKey(),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  name: text("name").notNull(),
  role: text("role", { enum: ["admin", "vendor", "buyer", "b2b"] }).notNull().default("buyer"),
  companyName: text("company_name"),          // B2B
  phone: text("phone"),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull(),
});

// ─── Vendors ─────────────────────────────────────────────────────────────────
export const vendors = sqliteTable("vendors", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id),
  storeName: text("store_name").notNull(),
  slug: text("slug").notNull().unique(),
  description: text("description"),
  logo: text("logo"),
  status: text("status", { enum: ["pending", "approved", "suspended"] }).notNull().default("pending"),
  commissionRate: real("commission_rate").notNull().default(10), // %
  createdAt: integer("created_at", { mode: "timestamp" }).notNull(),
});

// ─── Categories ──────────────────────────────────────────────────────────────
export const categories = sqliteTable("categories", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  parentId: text("parent_id"),
  image: text("image"),
});

// ─── Products ────────────────────────────────────────────────────────────────
export const products = sqliteTable("products", {
  id: text("id").primaryKey(),
  vendorId: text("vendor_id").notNull().references(() => vendors.id),
  categoryId: text("category_id").references(() => categories.id),
  name: text("name").notNull(),
  slug: text("slug").notNull(),
  description: text("description"),
  price: real("price").notNull(),              // B2C price
  wholesalePrice: real("wholesale_price"),     // B2B price
  compareAtPrice: real("compare_at_price"),
  sku: text("sku"),
  stock: integer("stock").notNull().default(0),
  minOrderQty: integer("min_order_qty").default(1), // B2B
  images: text("images"),                      // JSON array
  status: text("status", { enum: ["draft", "active", "archived"] }).notNull().default("draft"),
  featured: integer("featured", { mode: "boolean" }).default(false),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull(),
});

// ─── Orders ──────────────────────────────────────────────────────────────────
export const orders = sqliteTable("orders", {
  id: text("id").primaryKey(),
  userId: text("user_id").references(() => users.id),
  orderNumber: text("order_number").notNull().unique(),
  status: text("status", {
    enum: ["pending", "paid", "processing", "shipped", "delivered", "cancelled", "refunded"]
  }).notNull().default("pending"),
  type: text("type", { enum: ["b2c", "b2b"] }).notNull().default("b2c"),
  subtotal: real("subtotal").notNull(),
  shipping: real("shipping").notNull().default(0),
  tax: real("tax").notNull().default(0),
  total: real("total").notNull(),
  currency: text("currency").notNull().default("USD"),
  shippingAddress: text("shipping_address"),   // JSON
  notes: text("notes"),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull(),
});

export const orderItems = sqliteTable("order_items", {
  id: text("id").primaryKey(),
  orderId: text("order_id").notNull().references(() => orders.id),
  productId: text("product_id").notNull().references(() => products.id),
  vendorId: text("vendor_id").notNull().references(() => vendors.id),
  name: text("name").notNull(),
  price: real("price").notNull(),
  quantity: integer("quantity").notNull(),
  total: real("total").notNull(),
});

// ─── Reviews ─────────────────────────────────────────────────────────────────
export const reviews = sqliteTable("reviews", {
  id: text("id").primaryKey(),
  productId: text("product_id").notNull().references(() => products.id),
  userId: text("user_id").notNull().references(() => users.id),
  rating: integer("rating").notNull(),
  title: text("title"),
  body: text("body"),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull(),
});

// ─── Cart (simple, session or user based) ────────────────────────────────────
export const cartItems = sqliteTable("cart_items", {
  id: text("id").primaryKey(),
  userId: text("user_id").references(() => users.id),
  sessionId: text("session_id"),
  productId: text("product_id").notNull().references(() => products.id),
  quantity: integer("quantity").notNull().default(1),
  createdAt: integer("created_at", { mode: "timestamp" }).notNull(),
});
