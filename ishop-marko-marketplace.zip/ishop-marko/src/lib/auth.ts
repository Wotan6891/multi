import { db } from "./db";
import { users } from "./schema";
import { eq } from "drizzle-orm";
import bcrypt from "bcryptjs";
import { nanoid } from "nanoid";

export type SessionUser = {
  id: string;
  email: string;
  name: string;
  role: "admin" | "vendor" | "buyer" | "b2b";
  companyName?: string | null;
};

// Very simple cookie-based session for the demo.
// In production use a proper session store or better-auth / lucia.
const SESSIONS = new Map<string, SessionUser>();

export async function hashPassword(password: string) {
  return bcrypt.hash(password, 10);
}

export async function verifyPassword(password: string, hash: string) {
  return bcrypt.compare(password, hash);
}

export async function login(email: string, password: string): Promise<{ user: SessionUser; token: string } | null> {
  const [user] = await db.select().from(users).where(eq(users.email, email)).limit(1);
  if (!user) return null;
  const ok = await verifyPassword(password, user.passwordHash);
  if (!ok) return null;

  const sessionUser: SessionUser = {
    id: user.id,
    email: user.email,
    name: user.name,
    role: user.role as SessionUser["role"],
    companyName: user.companyName,
  };

  const token = nanoid(32);
  SESSIONS.set(token, sessionUser);
  return { user: sessionUser, token };
}

export function getSession(token?: string | null): SessionUser | null {
  if (!token) return null;
  return SESSIONS.get(token) ?? null;
}

export function logout(token: string) {
  SESSIONS.delete(token);
}

export function requireRole(user: SessionUser | null, roles: SessionUser["role"][]) {
  if (!user || !roles.includes(user.role)) {
    throw new Response("Unauthorized", { status: 401 });
  }
  return user;
}
