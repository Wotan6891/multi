# ishop Marketplace

Multi-vendor e-commerce marketplace (B2C + B2B) built with **Marko.js** + **Bun**.

- **Storefront** → purple theme we designed (Tailwind)
- **Admin panel** → clean black & white
- **Vendor panel** → simple dark sidebar
- **Not bloated** → essential marketplace features only

## Stack

| Layer     | Tech                    |
|-----------|-------------------------|
| Runtime   | Bun                     |
| UI        | Marko 6 + @marko/run    |
| Styling   | Tailwind CSS (CDN)      |
| Database  | SQLite via drizzle-orm + bun:sqlite |
| Validation| Zod                     |

## Features (lean)

### Store (customer)
- Home, categories, product listing
- Multi-vendor store pages
- Cart + checkout flow (order creation + payment links)
- B2B: wholesale prices, company accounts, min order qty
- Account, orders, reviews
- Search

### Vendor
- Dashboard (sales, products, orders)
- Product CRUD
- Order management
- Payouts / earnings overview
- Store settings

### Admin (super)
- Dashboard KPIs
- Vendors (approve / suspend)
- Products moderation
- Orders overview
- Categories & commission rates
- Users (buyers + B2B companies)

## Project structure

```
src/
  routes/
    index.marko          # Store home (purple)
    admin/
      layout.marko       # B&W admin shell
      index.marko        # Admin dashboard
    vendor/
      layout.marko
      index.marko
    account/
    api/
  components/
    store/               # Purple theme components
    admin/               # B&W components
  lib/
    schema.ts            # Full marketplace schema
    db.ts
    auth.ts              # Simple session auth
  styles/
    store.css
    admin.css
```

> **Note on routing files**: Marko Run normally uses `+page.marko` / `+layout.marko`.  
> Due to environment limitations we used `index.marko` / `layout.marko`.  
> When you run it locally just rename them to the `+` prefix convention or configure `routesDir`.

## Quick start

```bash
bun install
bun run db:migrate   # after setting up drizzle config
bun run db:seed
bun run dev
```

- Store → http://localhost:3000  
- Admin → http://localhost:3000/admin  
- Vendor → http://localhost:3000/vendor  

## Schema highlights (src/lib/schema.ts)

- `users` (roles: admin | vendor | buyer | b2b)
- `vendors` (status, commissionRate)
- `products` (price + wholesalePrice, minOrderQty)
- `orders` + `orderItems` (type: b2c | b2b)
- `reviews`, `cartItems`, `categories`

## Design rules

1. Storefront keeps the purple/pink visual language.
2. Admin & Vendor stay pure black / white / gray.
3. Prefer server-rendered Marko + minimal client JS.
4. Payments: Stripe Payment Links or create pending orders (keep v1 simple).

## Next steps you can add

- Real Stripe Checkout + webhooks
- Image upload (local or S3)
- Email (order confirmations)
- Better auth (better-auth / lucia)
- Advanced B2B (RFQ, contracts, credit terms)

Keep it simple. Ship fast.
